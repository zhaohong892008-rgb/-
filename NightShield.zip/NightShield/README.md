# 夜间卫士 NightShield

Android 手机安全检测 + 夜间防盗刷 App(Kotlin + Jetpack Compose)。

## 编译 APK

**方式一:GitHub Actions(不用装软件)**
1. 新建 GitHub 仓库,把本项目全部文件(含 `.github` 目录)上传到 main 分支
2. 打开仓库 Actions 页 → "Build APK" 运行完成 → 页面底部 Artifacts 下载 `NightShield-debug-apk`,解压得到 `app-debug.apk`

**方式二:Android Studio**
1. 用 Android Studio(Koala 及以上)打开本目录,JDK 17
2. 若提示缺少 Gradle Wrapper,选择 Gradle 8.7(或终端执行 `gradle wrapper --gradle-version 8.7`)
3. Build > Build APK(s)

## 首次使用
1. 安装 APK(允许安装未知来源应用)
2. 「夜间防护」页:授权 VPN → 打开「启用夜间防护」→ 设定时段 → 打开「定时断网」
3. 「夜间防护」页:开启「使用情况访问」(用于检测远控软件活动)
4. 「系统」页:填写 VirusTotal API Key(可选)
5. 「扫描」页:开始扫描

## 功能
- 应用扫描:权限/组件风险、安装来源、隐藏图标、签名、DEX 静态特征、native/assets 载荷、加壳、规则库家族匹配、VirusTotal 哈希查询
- 新应用安装后自动扫描并告警
- 监控新增的无障碍 / 设备管理员 / 通知读取授权
- 夜间亮屏告警、夜间远控软件检测、定时/触发式 VPN 黑洞断网、白名单
- 关闭防护、恢复网络都需要指纹或锁屏验证
- 系统检查:Root、USB/无线调试、锁屏、安全补丁、危险授权清单

## 重要说明
- 不要把本应用设成系统「始终开启的 VPN」+「阻止没有 VPN 的连接」,否则白天也会断网
- 规则库 `app/src/main/assets/rules.json` 内置样本黑名单为空,请自行维护或在线更新
- 评分是风险参考,会有误报(如短信类正规应用)
- 本项目未在真机上测试,首次编译可能需要微调

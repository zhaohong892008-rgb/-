package com.nightshield

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.zip.ZipFile

data class Finding(val text: String, val score: Int)

data class AppReport(
    val pkg: String,
    val label: String,
    val sha256: String,
    val findings: List<Finding>
) {
    val score: Int get() = findings.sumOf { it.score }
    val level: String
        get() = when {
            score >= 12 -> "高危"
            score >= 6 -> "中危"
            score >= 3 -> "低危"
            else -> "安全"
        }
}

class ApkScanner(private val c: Context) {
    private val pm = c.packageManager
    private val rules = Rules.load(c)

    companion object {
        val FLAGS = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or
            PackageManager.GET_RECEIVERS or PackageManager.GET_SIGNING_CERTIFICATES

        val PERM = mapOf(
            "BIND_ACCESSIBILITY_SERVICE" to (4 to "无障碍服务(可读屏/自动点击)"),
            "BIND_DEVICE_ADMIN" to (4 to "设备管理员(难卸载)"),
            "BIND_NOTIFICATION_LISTENER_SERVICE" to (3 to "通知读取(可截获验证码)"),
            "READ_SMS" to (2 to "读取短信"),
            "RECEIVE_SMS" to (2 to "接收短信"),
            "SEND_SMS" to (2 to "发送短信"),
            "SYSTEM_ALERT_WINDOW" to (2 to "悬浮窗(可伪造界面)"),
            "REQUEST_INSTALL_PACKAGES" to (2 to "可安装其他应用"),
            "RECORD_AUDIO" to (1 to "录音"),
            "READ_CONTACTS" to (1 to "读取通讯录"),
            "READ_CALL_LOG" to (1 to "读取通话记录"),
            "MANAGE_EXTERNAL_STORAGE" to (1 to "管理所有文件")
        )

        val STORES = setOf(
            "com.android.vending", "com.huawei.appmarket", "com.xiaomi.market", "com.xiaomi.mipicks",
            "com.heytap.market", "com.oppo.market", "com.bbk.appstore", "com.vivo.appstore",
            "com.tencent.android.qqdownloader", "com.sec.android.app.samsungapps",
            "com.hihonor.appmarket", "com.baidu.appsearch", "com.qihoo.appstore",
            "com.coolapk.market", "com.amazon.venezia"
        )

        // token, 说明, 分数
        val DEX_PATTERNS = listOf(
            Triple("DexClassLoader", "动态加载代码(DexClassLoader)", 2),
            Triple("dispatchGesture", "可模拟手势点击(无障碍)", 3),
            Triple("performGlobalAction", "无障碍全局操作", 1),
            Triple("createScreenCaptureIntent", "屏幕录制/投屏能力", 3),
            Triple("sendTextMessage", "可发送短信", 2),
            Triple("setComponentEnabledSetting", "可动态隐藏组件/图标", 1)
        )
        val SO_TOKENS = listOf("/system/xbin/su", "/system/bin/su", "su -c")

        fun label(c: Context, pkg: String): String = try {
            val pm = c.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

        fun sha256(b: ByteArray): String =
            MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

        fun sha256(f: File): String {
            val md = MessageDigest.getInstance("SHA-256")
            f.inputStream().use { s ->
                val buf = ByteArray(65536)
                while (true) {
                    val n = s.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
            return md.digest().joinToString("") { "%02x".format(it) }
        }
    }

    private val tokens: Set<String> =
        (DEX_PATTERNS.map { it.first } + rules.families.flatMap { it.strAll + it.strAny }).toSet()

    @Suppress("DEPRECATION")
    fun installed(): List<PackageInfo> =
        pm.getInstalledPackages(FLAGS).filter {
            val fl = it.applicationInfo?.flags ?: 0
            (fl and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != c.packageName
        }

    @Suppress("DEPRECATION")
    fun scanPackage(pkg: String): AppReport? = try {
        analyze(pm.getPackageInfo(pkg, FLAGS))
    } catch (e: Exception) {
        null
    }

    fun analyze(pi: PackageInfo): AppReport {
        val ai = pi.applicationInfo!!
        val pkg = pi.packageName
        val f = ArrayList<Finding>()
        val perms = HashSet<String>()

        pi.requestedPermissions?.forEach { perms.add(it.substringAfterLast('.')) }
        pi.services?.forEach { s ->
            when (s.permission) {
                "android.permission.BIND_ACCESSIBILITY_SERVICE" -> perms.add("BIND_ACCESSIBILITY_SERVICE")
                "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" -> perms.add("BIND_NOTIFICATION_LISTENER_SERVICE")
                else -> {}
            }
        }
        pi.receivers?.forEach { r ->
            if (r.permission == "android.permission.BIND_DEVICE_ADMIN") perms.add("BIND_DEVICE_ADMIN")
        }
        for ((k, v) in PERM) if (k in perms) f.add(Finding("权限: ${v.second}", v.first))

        // 安装来源
        val src = try {
            pm.getInstallSourceInfo(pkg).installingPackageName
        } catch (e: Exception) {
            null
        }
        if (src == null || src !in STORES) f.add(Finding("非应用商店安装(来源: ${src ?: "未知/侧载"})", 2))

        // 隐藏图标
        if (pm.getLaunchIntentForPackage(pkg) == null) f.add(Finding("无桌面图标(可能隐藏运行)", 2))

        // 远控软件
        if (pkg in rules.remoteApps) f.add(Finding("远程控制软件(夜间被远程操作的常见途径)", 6))

        // 签名
        try {
            val sig = pi.signingInfo?.apkContentsSigners?.firstOrNull()
            if (sig != null) {
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(sig.toByteArray())) as X509Certificate
                if (cert.subjectX500Principal.name.contains("Android Debug", ignoreCase = true))
                    f.add(Finding("使用 Android 调试证书签名", 3))
                if (sha256(cert.encoded) in rules.badCerts) f.add(Finding("签名证书在恶意名单中", 20))
            }
        } catch (_: Exception) {
        }

        // 文件哈希
        val sha = try {
            sha256(File(ai.sourceDir))
        } catch (e: Exception) {
            ""
        }
        if (sha.isNotEmpty() && sha in rules.blacklist) f.add(Finding("命中本地恶意样本库", 20))

        // DEX / native / assets 静态分析
        val found = HashSet<String>()
        scanApk(ai.sourceDir, f, found)
        for ((tok, desc, sc) in DEX_PATTERNS) {
            if (tok !in found) continue
            if (tok == "sendTextMessage" && "SEND_SMS" !in perms) continue
            f.add(Finding("代码特征: $desc", sc))
        }

        // 规则库家族匹配
        for (fam in rules.families) {
            val ok = fam.permsAll.all { it in perms } &&
                (fam.permsAny.isEmpty() || fam.permsAny.any { it in perms }) &&
                fam.strAll.all { it in found } &&
                (fam.strAny.isEmpty() || fam.strAny.any { it in found })
            if (ok) f.add(Finding("规则命中: ${fam.name}", fam.score))
        }

        return AppReport(pkg, pm.getApplicationLabel(ai).toString(), sha, f)
    }

    private fun scanApk(path: String, f: MutableList<Finding>, found: MutableSet<String>) {
        try {
            ZipFile(path).use { z ->
                var soCount = 0
                var payload = false
                val packersHit = LinkedHashSet<String>()
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val n = e.name
                    when {
                        n.endsWith(".dex") && !n.contains('/') && e.size in 1..(64L shl 20) -> {
                            val s = String(z.getInputStream(e).readBytes(), Charsets.ISO_8859_1)
                            for (t in tokens) if (t !in found && s.contains(t)) found.add(t)
                        }
                        n.startsWith("lib/") && n.endsWith(".so") -> {
                            for (p in rules.packers) if (n.contains(p)) packersHit.add(p)
                            if (soCount < 6 && e.size in 1..(16L shl 20)) {
                                soCount++
                                val s = String(z.getInputStream(e).readBytes(), Charsets.ISO_8859_1)
                                if (SO_TOKENS.any { s.contains(it) } && "NATIVE_SU" !in found) {
                                    found.add("NATIVE_SU")
                                    f.add(Finding("native 库含 Root/su 命令痕迹", 2))
                                }
                            }
                        }
                        n.startsWith("assets/") &&
                            (n.endsWith(".dex") || n.endsWith(".jar") || n.endsWith(".apk")) -> payload = true
                    }
                }
                if (payload) f.add(Finding("assets 内嵌可执行载荷(dex/jar/apk)", 4))
                if (packersHit.isNotEmpty()) f.add(Finding("疑似加壳/加固: ${packersHit.joinToString()}", 1))
            }
        } catch (e: Exception) {
            f.add(Finding("APK 解析失败: ${e.javaClass.simpleName}", 0))
        }
    }
}

object VT {
    class Result(val malicious: Int, val total: Int)

    private fun cached(c: Context, sha: String): Result? {
        val p = Prefs.getStr(c, "vt_$sha").split("|")
        if (p.size != 3) return null
        val ts = p[0].toLongOrNull() ?: return null
        if (System.currentTimeMillis() - ts > 7 * 86_400_000L) return null
        return Result(p[1].toIntOrNull() ?: 0, p[2].toIntOrNull() ?: 0)
    }

    fun isCached(c: Context, sha: String) = cached(c, sha) != null

    fun query(c: Context, key: String, sha: String): Result {
        cached(c, sha)?.let { return it }
        val res = try {
            val body = Http.get("https://www.virustotal.com/api/v3/files/$sha", mapOf("x-apikey" to key))
            val st = JSONObject(body).getJSONObject("data").getJSONObject("attributes")
                .getJSONObject("last_analysis_stats")
            var total = 0
            val ks = st.keys()
            while (ks.hasNext()) total += st.optInt(ks.next())
            Result(st.optInt("malicious"), total)
        } catch (e: Http.HttpErr) {
            if (e.code == 404) Result(0, 0) else throw e
        }
        Prefs.setStr(c, "vt_$sha", "${System.currentTimeMillis()}|${res.malicious}|${res.total}")
        return res
    }
}

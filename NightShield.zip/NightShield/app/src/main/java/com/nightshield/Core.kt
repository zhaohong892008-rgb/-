package com.nightshield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalTime

object Prefs {
    const val GUARD_ON = "guard_on"
    const val AUTO_CUT = "auto_cut"
    const val SCREEN_ALERT = "screen_alert"
    const val SCREEN_CUT = "screen_cut"
    const val REMOTE_CUT = "remote_cut"
    const val START_H = "start_h"
    const val END_H = "end_h"
    const val WHITELIST = "whitelist"
    const val VT_KEY = "vt_key"
    const val RULES_URL = "rules_url"
    const val BLOCKED = "blocked"
    const val BLOCK_REASON = "block_reason"
    const val SNOOZE = "snooze_until"

    private fun sp(c: Context) = c.getSharedPreferences("ns", Context.MODE_PRIVATE)
    fun getBool(c: Context, k: String, d: Boolean = false) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun getLong(c: Context, k: String, d: Long) = sp(c).getLong(k, d)
    fun setLong(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
    fun getStr(c: Context, k: String, d: String = "") = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun getSet(c: Context, k: String): Set<String> = HashSet(sp(c).getStringSet(k, emptySet()) ?: emptySet())
    fun setSet(c: Context, k: String, v: Set<String>) = sp(c).edit().putStringSet(k, HashSet(v)).apply()
}

object Notifier {
    const val CH_ALERT = "alert"
    const val CH_GUARD = "guard"

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "安全告警", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_GUARD, "防护运行状态", NotificationManager.IMPORTANCE_LOW))
    }

    fun open(c: Context, unlock: Boolean = false): PendingIntent {
        val i = Intent(c, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (unlock) i.putExtra("unlock", true)
        return PendingIntent.getActivity(
            c, if (unlock) 1 else 0, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun alert(c: Context, title: String, text: String) {
        ensureChannels(c)
        val n = Notification.Builder(c, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open(c))
            .setAutoCancel(true)
            .build()
        try {
            c.getSystemService(NotificationManager::class.java)
                .notify((System.currentTimeMillis() % 100000).toInt() + 100, n)
        } catch (_: SecurityException) {
        }
    }
}

object Night {
    fun inWindow(c: Context, hour: Int = LocalTime.now().hour): Boolean {
        val s = Prefs.getInt(c, Prefs.START_H, 0)
        val e = Prefs.getInt(c, Prefs.END_H, 6)
        return when {
            s == e -> false
            s < e -> hour in s until e
            else -> hour >= s || hour < e
        }
    }
}

object Net {
    fun prepared(c: Context): Boolean = VpnService.prepare(c) == null

    fun block(c: Context, reason: String): Boolean {
        if (!prepared(c)) return false
        c.startService(Intent(c, NightVpnService::class.java).putExtra("reason", reason))
        return true
    }

    fun unblock(c: Context) {
        c.startService(Intent(c, NightVpnService::class.java).setAction(NightVpnService.ACTION_STOP))
    }

    /** 用户验证身份后恢复网络,1 小时内不再自动定时断网。 */
    fun restore(c: Context) {
        Prefs.setLong(c, Prefs.SNOOZE, System.currentTimeMillis() + 3_600_000L)
        unblock(c)
    }
}

object Http {
    class HttpErr(val code: Int) : Exception("HTTP $code")

    fun get(url: String, headers: Map<String, String>): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 15_000
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        try {
            val code = conn.responseCode
            if (code != 200) throw HttpErr(code)
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}

object Auth {
    fun prompt(a: FragmentActivity, title: String, ok: () -> Unit) {
        val auth = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(a).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(a, "未设置锁屏密码/指纹,无法验证身份,已直接执行。请尽快设置锁屏密码", Toast.LENGTH_LONG).show()
            ok()
            return
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(auth)
            .build()
        val bp = BiometricPrompt(a, ContextCompat.getMainExecutor(a),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    ok()
                }
            })
        bp.authenticate(info)
    }
}

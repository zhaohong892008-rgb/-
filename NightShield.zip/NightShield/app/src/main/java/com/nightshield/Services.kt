package com.nightshield

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat

/** 本地 VPN 黑洞:建立 VPN 并丢弃所有流量,等同断网。电话/短信不受影响。 */
class NightVpnService : VpnService() {
    companion object {
        const val ACTION_STOP = "com.nightshield.STOP"
        const val NOTIF_ID = 2
    }

    private var pfd: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopBlock()
            return START_NOT_STICKY
        }
        val reason = intent?.getStringExtra("reason")
        when {
            reason != null -> startBlock(reason)
            Prefs.getBool(this, Prefs.BLOCKED) ->
                startBlock(Prefs.getStr(this, Prefs.BLOCK_REASON, "trigger").ifEmpty { "trigger" })
            else -> {
                // 被系统「始终开启的VPN」等无参数拉起时,不主动断网
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun startBlock(reason: String) {
        if (pfd != null) {
            if (reason == "trigger") Prefs.setStr(this, Prefs.BLOCK_REASON, "trigger")
            return
        }
        val b = Builder().setSession("NightShield")
            .addAddress("10.255.0.1", 32)
            .addAddress("fd00:255::1", 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .setBlocking(true)
        for (p in Prefs.getSet(this, Prefs.WHITELIST)) {
            try {
                b.addDisallowedApplication(p)
            } catch (_: Exception) {
            }
        }
        pfd = try {
            b.establish()
        } catch (e: Exception) {
            null
        }
        if (pfd == null) {
            Notifier.alert(this, "断网失败", "请先在「夜间防护」页授权 VPN")
            stopSelf()
            return
        }
        Prefs.setStr(this, Prefs.BLOCK_REASON, reason)
        Prefs.setBool(this, Prefs.BLOCKED, true)
        showOngoing()
    }

    private fun stopBlock() {
        try {
            pfd?.close()
        } catch (_: Exception) {
        }
        pfd = null
        Prefs.setBool(this, Prefs.BLOCKED, false)
        Prefs.setStr(this, Prefs.BLOCK_REASON, "")
        getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        stopSelf()
    }

    private fun showOngoing() {
        Notifier.ensureChannels(this)
        val pi = Notifier.open(this, true)
        val n = Notification.Builder(this, Notifier.CH_GUARD)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("🌙 夜间断网已开启")
            .setContentText("所有联网已切断(电话/短信正常)。点击验证身份后恢复")
            .setOngoing(true)
            .setContentIntent(pi)
            .addAction(Notification.Action.Builder(0, "恢复网络(需验证)", pi).build())
            .build()
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
        } catch (_: SecurityException) {
        }
    }

    override fun onRevoke() {
        val was = Prefs.getBool(this, Prefs.BLOCKED)
        pfd = null
        Prefs.setBool(this, Prefs.BLOCKED, false)
        if (was) Notifier.alert(this, "⚠ 夜间断网被关闭", "断网 VPN 被系统或其他应用撤销。如非本人操作,请立即检查手机。")
        super.onRevoke()
    }

    override fun onDestroy() {
        try {
            pfd?.close()
        } catch (_: Exception) {
        }
        pfd = null
        super.onDestroy()
    }
}

/** 常驻监控:授权变化、新装应用、夜间亮屏、定时断网、夜间远控。 */
class GuardService : Service() {
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            try {
                check()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 60_000L)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_ON && Night.inWindow(c)) {
                if (Prefs.getBool(c, Prefs.SCREEN_ALERT, true))
                    Notifier.alert(c, "🌙 夜间亮屏", "手机在夜间防护时段被点亮。如非本人操作,请立即检查。")
                if (Prefs.getBool(c, Prefs.SCREEN_CUT)) Net.block(c, "trigger")
            }
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pkg = i.data?.schemeSpecificPart ?: return
            if (pkg == c.packageName) return
            val app = c.applicationContext
            Thread {
                val r = ApkScanner(app).scanPackage(pkg) ?: return@Thread
                if (r.score >= 3) {
                    Notifier.alert(
                        app, "⚠ 新安装应用有风险: ${r.label}(${r.level})",
                        r.findings.filter { it.score > 0 }.take(4).joinToString(";") { it.text }
                    )
                }
            }.start()
        }
    }

    private fun check() {
        val c = this
        Monitor.checkChanges(c)
        val snoozed = System.currentTimeMillis() < Prefs.getLong(c, Prefs.SNOOZE, 0L)
        if (Prefs.getBool(c, Prefs.AUTO_CUT) && !snoozed) {
            val blocked = Prefs.getBool(c, Prefs.BLOCKED)
            val reason = Prefs.getStr(c, Prefs.BLOCK_REASON)
            if (Night.inWindow(c)) {
                if (!blocked) Net.block(c, "schedule")
            } else if (blocked && reason == "schedule") {
                Net.unblock(c)
            }
        }
        if (Night.inWindow(c)) Monitor.checkRemoteActive(c)
    }

    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannels(this)
        ContextCompat.registerReceiver(
            this, screenReceiver, IntentFilter(Intent.ACTION_SCREEN_ON), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        val pf = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
        ContextCompat.registerReceiver(this, pkgReceiver, pf, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notification.Builder(this, Notifier.CH_GUARD)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("夜间卫士运行中")
            .setContentText("正在监控授权变化、新装应用与夜间异常")
            .setContentIntent(Notifier.open(this))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try {
            unregisterReceiver(screenReceiver)
            unregisterReceiver(pkgReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        // 重启后 VPN 已失效,清除旧状态,由 GuardService 按时段重新判断
        Prefs.setBool(c, Prefs.BLOCKED, false)
        Prefs.setStr(c, Prefs.BLOCK_REASON, "")
        if (Prefs.getBool(c, Prefs.GUARD_ON)) {
            c.startForegroundService(Intent(c, GuardService::class.java))
        }
    }
}

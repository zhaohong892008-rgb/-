package com.nightshield

import android.content.Context
import org.json.JSONObject
import java.io.File

data class Family(
    val name: String,
    val score: Int,
    val permsAll: List<String>,
    val permsAny: List<String>,
    val strAll: List<String>,
    val strAny: List<String>
)

class RuleSet(
    val version: Int,
    val blacklist: Set<String>,
    val badCerts: Set<String>,
    val remoteApps: Set<String>,
    val packers: List<String>,
    val families: List<Family>
)

object Rules {
    @Volatile
    private var cache: RuleSet? = null

    fun load(c: Context): RuleSet {
        cache?.let { return it }
        val f = File(c.filesDir, "rules.json")
        val text = try {
            if (f.exists()) f.readText() else c.assets.open("rules.json").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            c.assets.open("rules.json").bufferedReader().use { it.readText() }
        }
        val r = parse(text)
        cache = r
        return r
    }

    private fun arr(o: JSONObject, k: String): List<String> {
        val a = o.optJSONArray(k) ?: return emptyList()
        return List(a.length()) { a.getString(it) }
    }

    fun parse(text: String): RuleSet {
        val j = JSONObject(text)
        val fa = j.optJSONArray("families")
        val fams = if (fa == null) emptyList() else List(fa.length()) { i ->
            val o = fa.getJSONObject(i)
            Family(
                o.getString("name"), o.getInt("score"),
                arr(o, "perms_all"), arr(o, "perms_any"), arr(o, "str_all"), arr(o, "str_any")
            )
        }
        return RuleSet(
            j.optInt("version"),
            arr(j, "blacklist_sha256").map { it.lowercase() }.toSet(),
            arr(j, "bad_cert_sha256").map { it.lowercase() }.toSet(),
            arr(j, "remote_apps").toSet(),
            arr(j, "packers"),
            fams
        )
    }

    /** 阻塞调用,请在后台线程执行。只接受 https。 */
    fun update(c: Context, url: String): String {
        require(url.startsWith("https://")) { "规则地址必须以 https:// 开头" }
        val txt = Http.get(url, emptyMap())
        val r = parse(txt)
        File(c.filesDir, "rules.json").writeText(txt)
        cache = r
        return "规则库已更新到 v${r.version}"
    }
}

package com.nightshield

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import java.io.File
import java.time.LocalDate
import java.time.temporal.ChronoUnit

object Monitor {
    fun accessibility(c: Context): Set<String> {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return emptySet()
        return s.split(":").filter { it.isNotBlank() }.map { it.substringBefore("/") }.toSet()
    }

    fun admins(c: Context): Set<String> {
        val dpm = c.getSystemService(DevicePolicyManager::class.java)
        return dpm.activeAdmins?.map { it.packageName }?.toSet() ?: emptySet()
    }

    fun listeners(c: Context): Set<String> = NotificationManagerCompat.getEnabledListenerPackages(c)

    /** 对比上次快照,发现新增的高危授权就告警。首次运行只建立快照。 */
    fun checkChanges(c: Context) {
        val now = mapOf("acc" to accessibility(c), "adm" to admins(c), "ntf" to listeners(c))
        val names = mapOf("acc" to "无障碍服务", "adm" to "设备管理员", "ntf" to "通知读取")
        val first = !Prefs.getBool(c, "snap_init")
        for ((k, set) in now) {
            val old = Prefs.getSet(c, "snap_$k")
            if (!first) {
                for (p in set - old) {
                    Notifier.alert(
                        c, "⚠ 新增${names[k]}授权",
                        "${ApkScanner.label(c, p)} ($p) 刚刚获得${names[k]}权限。如非本人操作,请立即关闭并检查手机。"
                    )
                }
            }
            Prefs.setSet(c, "snap_$k", set)
        }
        Prefs.setBool(c, "snap_init", true)
    }

    /** 需要用户授予「使用情况访问」。夜间 2 分钟内使用过远控软件则告警(并可断网)。 */
    fun checkRemoteActive(c: Context) {
        val usm = c.getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val remote = Rules.load(c).remoteApps
        val hit = (usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 120_000, now) ?: emptyList())
            .filter { it.packageName in remote && it.lastTimeUsed > now - 120_000 }
        if (hit.isEmpty()) return
        if (now - Prefs.getLong(c, "last_remote_alert", 0L) > 600_000L) {
            Prefs.setLong(c, "last_remote_alert", now)
            val names = hit.joinToString { ApkScanner.label(c, it.packageName) }
            Notifier.alert(c, "🚨 夜间检测到远控软件活动", "$names 在夜间被使用。如非本人操作,请立即断开并联系银行冻结卡片。")
        }
        if (Prefs.getBool(c, Prefs.REMOTE_CUT, true)) Net.block(c, "trigger")
    }
}

object SystemCheck {
    data class Check(val title: String, val detail: String, val ok: Boolean)

    @Suppress("DEPRECATION")
    fun run(c: Context): List<Check> {
        val out = ArrayList<Check>()
        val pm = c.packageManager
        val cr = c.contentResolver

        // Root
        val suPaths = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/app/Superuser.apk"
        ).filter { File(it).exists() }
        val rootPkgs = listOf(
            "com.topjohnwu.magisk", "eu.chainfire.supersu", "com.koushikdutta.superuser", "com.noshufou.android.su"
        ).filter { try { pm.getPackageInfo(it, 0); true } catch (e: Exception) { false } }
        val testKeys = Build.TAGS?.contains("test-keys") == true
        val rooted = suPaths.isNotEmpty() || rootPkgs.isNotEmpty() || testKeys
        out += Check(
            "Root 状态",
            if (rooted) "发现 Root 痕迹: ${(suPaths + rootPkgs + (if (testKeys) listOf("test-keys") else emptyList())).joinToString()}"
            else "未发现 Root 痕迹(无法排除被隐藏的 Root)",
            !rooted
        )

        val adb = Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1
        out += Check("USB 调试", if (adb) "已开启,建议关闭" else "已关闭", !adb)

        val wadb = Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1
        out += Check("无线调试", if (wadb) "已开启,建议关闭" else "已关闭", !wadb)

        val secure = c.getSystemService(KeyguardManager::class.java).isDeviceSecure
        out += Check("锁屏密码", if (secure) "已设置" else "未设置锁屏密码,风险很高", secure)

        try {
            val d = LocalDate.parse(Build.VERSION.SECURITY_PATCH)
            val days = ChronoUnit.DAYS.between(d, LocalDate.now())
            out += Check("系统安全补丁", "${Build.VERSION.SECURITY_PATCH}(距今 $days 天)", days <= 180)
        } catch (e: Exception) {
            out += Check("系统安全补丁", "无法读取", true)
        }

        fun names(s: Set<String>) = if (s.isEmpty()) "无" else s.joinToString { ApkScanner.label(c, it) }
        val acc = Monitor.accessibility(c)
        out += Check("已启用的无障碍服务", names(acc) + (if (acc.isNotEmpty()) "\n请确认都是你自己开启的" else ""), acc.isEmpty())
        val adm = Monitor.admins(c)
        out += Check("设备管理员", names(adm) + (if (adm.isNotEmpty()) "\n请确认都是你自己开启的" else ""), adm.isEmpty())
        val ntf = Monitor.listeners(c)
        out += Check("通知读取权限", names(ntf) + (if (ntf.isNotEmpty()) "\n请确认都是你自己开启的" else ""), ntf.isEmpty())

        val all = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        val withInstall = all.filter {
            ((it.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                it.requestedPermissions?.contains("android.permission.REQUEST_INSTALL_PACKAGES") == true
        }.map { ApkScanner.label(c, it.packageName) }
        out += Check(
            "声明「安装未知应用」的第三方应用",
            if (withInstall.isEmpty()) "无" else withInstall.joinToString(),
            withInstall.size <= 3
        )

        val remote = Rules.load(c).remoteApps.filter { p -> all.any { it.packageName == p } }
            .map { ApkScanner.label(c, it) }
        out += Check(
            "已安装的远控软件",
            if (remote.isEmpty()) "未发现" else remote.joinToString() + "\n不用时建议卸载",
            remote.isEmpty()
        )
        return out
    }
}

package com.nightshield

import android.Manifest
import android.app.Application
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    private val vm: ScanVM by viewModels()
    private var pendingUnlock = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannels(this)
        handleIntent(intent)
        setContent { MaterialTheme { Root(vm, this@MainActivity) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("unlock", false) == true) {
            i.removeExtra("unlock")
            pendingUnlock = true
        }
    }

    override fun onResume() {
        super.onResume()
        if (pendingUnlock) {
            pendingUnlock = false
            Auth.prompt(this, "验证身份以恢复网络") { Net.restore(this) }
        }
    }
}

class ScanVM(app: Application) : AndroidViewModel(app) {
    val reports = mutableStateListOf<AppReport>()
    var scanning by mutableStateOf(false)
    var progress by mutableStateOf("")
    var vtStatus by mutableStateOf("")

    fun scan() {
        if (scanning) return
        scanning = true
        reports.clear()
        vtStatus = ""
        viewModelScope.launch(Dispatchers.Default) {
            val sc = ApkScanner(getApplication())
            val list = sc.installed()
            list.forEachIndexed { i, pi ->
                val r = try {
                    sc.analyze(pi)
                } catch (e: Exception) {
                    null
                }
                withContext(Dispatchers.Main) {
                    progress = "${i + 1}/${list.size}"
                    if (r != null) {
                        reports.add(r)
                        reports.sortByDescending { it.score }
                    }
                }
            }
            withContext(Dispatchers.Main) {
                scanning = false
                progress = ""
            }
            vtPass()
        }
    }

    private suspend fun vtPass() {
        val app = getApplication<Application>()
        val key = Prefs.getStr(app, Prefs.VT_KEY).trim()
        if (key.isEmpty()) {
            withContext(Dispatchers.Main) { vtStatus = "未填写 VirusTotal Key,已跳过云查杀(在「系统」页填写)" }
            return
        }
        val targets = withContext(Dispatchers.Main) {
            reports.filter { it.score >= 3 && it.sha256.isNotEmpty() }.map { it.pkg to it.sha256 }
        }
        var done = 0
        for ((pkg, sha) in targets) {
            withContext(Dispatchers.Main) { vtStatus = "云查杀 ${done + 1}/${targets.size} …" }
            val wasCached = VT.isCached(app, sha)
            val res = try {
                VT.query(app, key, sha)
            } catch (e: Http.HttpErr) {
                withContext(Dispatchers.Main) {
                    vtStatus = when (e.code) {
                        429 -> "VirusTotal 额度已用尽,稍后再试"
                        401 -> "VirusTotal Key 无效"
                        else -> "云查杀失败 HTTP ${e.code}"
                    }
                }
                return
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { vtStatus = "云查杀失败:网络不可用(夜间断网中?)" }
                return
            }
            withContext(Dispatchers.Main) {
                val idx = reports.indexOfFirst { it.pkg == pkg }
                if (idx >= 0) {
                    val extra = when {
                        res.total == 0 -> Finding("VirusTotal 无该文件记录", 0)
                        res.malicious >= 3 -> Finding("VirusTotal ${res.malicious}/${res.total} 个引擎报毒", 20)
                        res.malicious > 0 -> Finding("VirusTotal ${res.malicious}/${res.total} 个引擎报毒(数量少,可能误报)", 3)
                        else -> Finding("VirusTotal 0/${res.total} 报毒", 0)
                    }
                    reports[idx] = reports[idx].copy(findings = reports[idx].findings + extra)
                    reports.sortByDescending { it.score }
                }
            }
            done++
            if (!wasCached) delay(16_000L) // 免费 Key 每分钟 4 次
        }
        withContext(Dispatchers.Main) { vtStatus = "云查杀完成" }
    }
}

@Composable
fun Root(vm: ScanVM, act: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("扫描" to "🔍", "夜间防护" to "🌙", "系统" to "⚙️")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i },
                    icon = { Text(t.second) },
                    label = { Text(t.first) }
                )
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ScanTab(vm)
                1 -> GuardTab(act)
                else -> SystemTab()
            }
        }
    }
}

fun reportText(list: List<AppReport>): String = buildString {
    append("夜间卫士 扫描报告\n")
    append(java.time.LocalDateTime.now()).append("\n\n")
    list.forEach { r ->
        append("[${r.level}] ${r.label} (${r.pkg}) 得分 ${r.score}\n")
        r.findings.forEach { append("  - ${it.text}\n") }
    }
}

@Composable
fun ScanTab(vm: ScanVM) {
    val ctx = LocalContext.current
    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("应用扫描", style = MaterialTheme.typography.headlineSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.scan() }, enabled = !vm.scanning) {
                        Text(if (vm.scanning) "扫描中 ${vm.progress}" else "开始扫描")
                    }
                    OutlinedButton(
                        enabled = vm.reports.isNotEmpty(),
                        onClick = {
                            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, reportText(vm.reports.toList()).take(200_000))
                            ctx.startActivity(Intent.createChooser(send, "导出报告"))
                        }
                    ) { Text("导出报告") }
                }
                if (vm.vtStatus.isNotEmpty()) Text(vm.vtStatus, style = MaterialTheme.typography.bodySmall)
                Text(
                    "评分仅为风险参考:分数高表示「值得检查」,不等于一定是病毒。点击条目查看依据。",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        items(vm.reports, key = { it.pkg }) { r -> AppCard(r) }
    }
}

@Composable
fun AppCard(r: AppReport) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val color = when (r.level) {
        "高危" -> Color(0xFFD32F2F)
        "中危" -> Color(0xFFF57C00)
        "低危" -> Color(0xFFB8860B)
        else -> Color(0xFF388E3C)
    }
    Card(Modifier.fillMaxWidth().clickable { open = !open }) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.label, style = MaterialTheme.typography.titleMedium)
                    Text(r.pkg, style = MaterialTheme.typography.bodySmall)
                }
                Text("${r.level} ${r.score}", color = color, style = MaterialTheme.typography.titleSmall)
            }
            if (open) {
                Spacer(Modifier.height(6.dp))
                if (r.findings.isEmpty()) Text("未发现可疑特征", style = MaterialTheme.typography.bodySmall)
                r.findings.forEach {
                    Text("• ${it.text}" + (if (it.score > 0) "(+${it.score})" else ""), style = MaterialTheme.typography.bodySmall)
                }
                if (r.sha256.isNotEmpty()) Text("SHA-256: ${r.sha256.take(16)}…", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${r.pkg}")))
                    }) { Text("应用详情") }
                    Button(onClick = {
                        ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${r.pkg}")))
                    }) { Text("卸载") }
                }
            }
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(sub, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun GuardTab(act: MainActivity) {
    val ctx = LocalContext.current
    var guardOn by remember { mutableStateOf(Prefs.getBool(ctx, Prefs.GUARD_ON)) }
    var autoCut by remember { mutableStateOf(Prefs.getBool(ctx, Prefs.AUTO_CUT)) }
    var screenAlert by remember { mutableStateOf(Prefs.getBool(ctx, Prefs.SCREEN_ALERT, true)) }
    var screenCut by remember { mutableStateOf(Prefs.getBool(ctx, Prefs.SCREEN_CUT)) }
    var remoteCut by remember { mutableStateOf(Prefs.getBool(ctx, Prefs.REMOTE_CUT, true)) }
    var startH by remember { mutableIntStateOf(Prefs.getInt(ctx, Prefs.START_H, 0)) }
    var endH by remember { mutableIntStateOf(Prefs.getInt(ctx, Prefs.END_H, 6)) }
    var blocked by remember { mutableStateOf(Prefs.getBool(ctx, Prefs.BLOCKED)) }
    var vpnOk by remember { mutableStateOf(Net.prepared(ctx)) }
    var showWl by remember { mutableStateOf(false) }
    var wl by remember { mutableStateOf(Prefs.getSet(ctx, Prefs.WHITELIST)) }

    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vpnOk = Net.prepared(ctx)
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        while (true) {
            blocked = Prefs.getBool(ctx, Prefs.BLOCKED)
            vpnOk = Net.prepared(ctx)
            delay(2000)
        }
    }

    // 关闭防护必须通过指纹/锁屏验证,防止被远程操作者关掉
    fun secure(want: Boolean, apply: (Boolean) -> Unit) {
        if (want) apply(true) else Auth.prompt(act, "验证身份以关闭防护") { apply(false) }
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("夜间防护", style = MaterialTheme.typography.headlineSmall)
        Text(
            "VPN 授权:${if (vpnOk) "已授权" else "未授权"}    当前断网:${if (blocked) "是" else "否"}",
            style = MaterialTheme.typography.bodyMedium
        )
        if (!vpnOk) {
            Button(onClick = {
                val i = VpnService.prepare(ctx)
                if (i != null) vpnLauncher.launch(i)
            }) { Text("授权 VPN(断网功能必需)") }
        }

        SwitchRow("启用夜间防护", "常驻监控授权变化、新装应用、夜间异常。关闭需验证身份", guardOn) { want ->
            secure(want) { v ->
                guardOn = v
                Prefs.setBool(ctx, Prefs.GUARD_ON, v)
                val i = Intent(ctx, GuardService::class.java)
                if (v) {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    ctx.startForegroundService(i)
                } else {
                    ctx.stopService(i)
                }
            }
        }

        Text("防护时段", style = MaterialTheme.typography.titleSmall)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("开始 %02d:00".format(startH))
            OutlinedButton(onClick = { startH = (startH + 23) % 24; Prefs.setInt(ctx, Prefs.START_H, startH) }) { Text("−") }
            OutlinedButton(onClick = { startH = (startH + 1) % 24; Prefs.setInt(ctx, Prefs.START_H, startH) }) { Text("+") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("结束 %02d:00".format(endH))
            OutlinedButton(onClick = { endH = (endH + 23) % 24; Prefs.setInt(ctx, Prefs.END_H, endH) }) { Text("−") }
            OutlinedButton(onClick = { endH = (endH + 1) % 24; Prefs.setInt(ctx, Prefs.END_H, endH) }) { Text("+") }
        }

        SwitchRow("定时断网", "防护时段内自动切断联网。关闭需验证身份", autoCut) { want ->
            secure(want) { v -> autoCut = v; Prefs.setBool(ctx, Prefs.AUTO_CUT, v) }
        }
        SwitchRow("夜间亮屏告警", "防护时段屏幕被点亮时推送提醒", screenAlert) { v ->
            screenAlert = v; Prefs.setBool(ctx, Prefs.SCREEN_ALERT, v)
        }
        SwitchRow("夜间亮屏即断网", "更严格,但夜里自己看手机也会断网", screenCut) { v ->
            screenCut = v; Prefs.setBool(ctx, Prefs.SCREEN_CUT, v)
        }
        SwitchRow("检测到远控即断网", "需开启「使用情况访问」才能检测远控软件活动", remoteCut) { v ->
            remoteCut = v; Prefs.setBool(ctx, Prefs.REMOTE_CUT, v)
        }

        OutlinedButton(onClick = { showWl = true }) { Text("断网白名单(${wl.size})") }
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) {
            Text("开启「使用情况访问」(检测远控)")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = vpnOk && !blocked, onClick = { Net.block(ctx, "trigger") }) { Text("立即断网") }
            Button(enabled = blocked, onClick = {
                Auth.prompt(act, "验证身份以恢复网络") { Net.restore(ctx) }
            }) { Text("恢复网络(需验证)") }
        }

        Text(
            "提示:请不要在系统里把本应用设为「始终开启的 VPN」并开启「阻止没有 VPN 的连接」,否则白天也会断网。",
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            "断网只切断联网(含银行 App、远控软件),电话和短信不受影响。若攻击者已获得无障碍控制权,理论上仍可能关闭 VPN,断网被撤销时本应用会告警。",
            style = MaterialTheme.typography.bodySmall
        )
    }

    if (showWl) {
        val apps = remember {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val pm = ctx.packageManager
            pm.queryIntentActivities(i, 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .sortedBy { it.second }
        }
        AlertDialog(
            onDismissRequest = { showWl = false },
            confirmButton = { TextButton(onClick = { showWl = false }) { Text("完成") } },
            title = { Text("断网白名单(勾选的应用不会被断网)") },
            text = {
                LazyColumn(Modifier.heightIn(max = 400.dp)) {
                    items(apps) { app ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = app.first in wl, onCheckedChange = { v ->
                                wl = if (v) wl + app.first else wl - app.first
                                Prefs.setSet(ctx, Prefs.WHITELIST, wl)
                            })
                            Text(app.second)
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun SystemTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var checks by remember { mutableStateOf(SystemCheck.run(ctx)) }
    var vtKey by remember { mutableStateOf(Prefs.getStr(ctx, Prefs.VT_KEY)) }
    var url by remember { mutableStateOf(Prefs.getStr(ctx, Prefs.RULES_URL)) }
    var msg by remember { mutableStateOf("") }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("系统安全检查", style = MaterialTheme.typography.headlineSmall)
        OutlinedButton(onClick = { checks = SystemCheck.run(ctx) }) { Text("重新检查") }
        checks.forEach { ch ->
            Text((if (ch.ok) "✅ " else "⚠️ ") + ch.title, style = MaterialTheme.typography.titleSmall)
            Text(ch.detail, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(12.dp))
        Text("云查杀与规则库", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = vtKey,
            onValueChange = { vtKey = it; Prefs.setStr(ctx, Prefs.VT_KEY, it.trim()) },
            label = { Text("VirusTotal API Key") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = url,
            onValueChange = { url = it; Prefs.setStr(ctx, Prefs.RULES_URL, it.trim()) },
            label = { Text("规则更新地址(https://…/rules.json)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            scope.launch(Dispatchers.IO) {
                val r = try {
                    Rules.update(ctx.applicationContext, url.trim())
                } catch (e: Exception) {
                    "更新失败: ${e.message}"
                }
                withContext(Dispatchers.Main) { msg = r }
            }
        }) { Text("更新规则库") }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
        Text("当前规则库版本: v${Rules.load(ctx).version}", style = MaterialTheme.typography.bodySmall)
    }
}
